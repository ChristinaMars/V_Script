CREATE TABLE `pa_cats` (
  `id` int(11) NOT NULL auto_increment,
  `categories` varchar(255) collate latin1_general_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

INSERT INTO `pa_cats` VALUES (1, 'Big Tits');
INSERT INTO `pa_cats` VALUES (2, 'Teens');
INSERT INTO `pa_cats` VALUES (3, 'Lesbian');
INSERT INTO `pa_cats` VALUES (4, 'Anal');
INSERT INTO `pa_cats` VALUES (5, 'Blow Job');
INSERT INTO `pa_cats` VALUES (6, 'Asian');
INSERT INTO `pa_cats` VALUES (7, 'Gay');
INSERT INTO `pa_cats` VALUES (8, 'Public');
INSERT INTO `pa_cats` VALUES (9, 'Milf');
INSERT INTO `pa_cats` VALUES (10, 'Amateur');
INSERT INTO `pa_cats` VALUES (11, 'Ass');
INSERT INTO `pa_cats` VALUES (12, 'Babe');
INSERT INTO `pa_cats` VALUES (13, 'Big Dick');
INSERT INTO `pa_cats` VALUES (14, 'Blond');
INSERT INTO `pa_cats` VALUES (15, 'Brunette');
INSERT INTO `pa_cats` VALUES (16, 'Creampie');
INSERT INTO `pa_cats` VALUES (17, 'Cumshot');
INSERT INTO `pa_cats` VALUES (18, 'Ebony');
INSERT INTO `pa_cats` VALUES (19, 'Group');
INSERT INTO `pa_cats` VALUES (20, 'Handjob');
INSERT INTO `pa_cats` VALUES (21, 'Pornstar');
INSERT INTO `pa_cats` VALUES (22, 'Masturbation');
INSERT INTO `pa_cats` VALUES (23, 'Toys');
INSERT INTO `pa_cats` VALUES (24, 'Striptease');
INSERT INTO `pa_cats` VALUES (25, 'Uncategorized');

CREATE TABLE `pa_settings` (
  `id` int(11) NOT NULL auto_increment,
  `sitename` varchar(255) collate latin1_general_ci NOT NULL default '',
  `url` varchar(255) collate latin1_general_ci NOT NULL default '',
  `email` varchar(255) collate latin1_general_ci NOT NULL default '',
  `username` varchar(100) collate latin1_general_ci NOT NULL default '',
  `passencrypt` text collate latin1_general_ci NOT NULL,
  `themedir` varchar(255) collate latin1_general_ci NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;


INSERT INTO `pa_settings` (`id`, `sitename`, `url`, `email`, `username`, `passencrypt`, `themedir`) VALUES
(1, 'XpModderz', '', 'postmaster@localhost', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'classic');

CREATE TABLE `pa_videos` (
  `id` bigint(11) NOT NULL auto_increment,
  `embedCode` text collate latin1_general_ci NOT NULL,
  `title` varchar(255) collate latin1_general_ci NOT NULL default '',
  `duration` varchar(255) collate latin1_general_ci NOT NULL default '',
  `source` varchar(100) collate latin1_general_ci NOT NULL default '',
  `category` varchar(100) collate latin1_general_ci NOT NULL default '',
  `img` varchar(255) collate latin1_general_ci NOT NULL default '',
  `description` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;