<?php
  // This function creates a connection to your database and can be used in any file
  function db_connect() {
    global $dbhost;
    global $dbuser;
    global $dbpassword;
    global $dbname;
  
		@mysql_connect("$dbhost", "$dbuser", "$dbpassword") or die("Could Not Establish A Database Connection. Please Verify Your pa-config.php Settings And Try Again.");
    @mysql_select_db("$dbname");
	}
	
	// This function closes the connection to the database and can be used in any file
	function db_close()
  {
    @mysql_close();
  }
  
  // this function returns specific information about your website
  // name = name of the website (Also used in title tags)
  // url = the url link of your website
  // email = the email address you specified during the installtion and in your options panel
  // powered = this returns a message which looks like this "Powered By AdultProfits V1.0"
  // this function can also be used on every page
  function painfo($name, $display = true) {
    if($name == 'version'){
      return "V1.0";
    }
    
    if($name == 'name'){
      // find the websites name
      db_connect();
        $query = "SELECT sitename FROM pa_settings WHERE id = 1";
        $result = @mysql_query($query);
        
        while($row = @mysql_fetch_array($result)) {
          $site = $row['sitename'];
        }
      db_close();
      
      if($display == true){
        echo $site;
      }
      else
      {
        return $site;
      }
    }
    
    if($name == 'url'){
      // find the websites name
      db_connect();
        $query = "SELECT url FROM pa_settings WHERE id = 1";
        $result = @mysql_query($query);
        
        while($row = @mysql_fetch_array($result)) {
          $url = $row['url'];
        }
      db_close();
      
      if($display == true){
        echo $url;
      }
      elseif($display == false)
      {
        return $url;
      }
    }
    
    if($name == 'email'){
      // find the websites name
      db_connect();
        $query = "SELECT email FROM pa_settings WHERE id = 1";
        $result = @mysql_query($query);
        
        while($row = @mysql_fetch_array($result)) {
          $email = $row['email'];
        }
      db_close();
      
      if($display == true){
        echo $email;
      }
      else
      {
        return $email;
      }
    }
    
    if($name == 'powered'){
      // find the websites name
      $powered = 'Powered By <a href="mailto:cornetofreak@gmail.com">XpModderz V1.1</a>';
      
      if($display == true){
        echo $powered;
      }
      else
      {
        return $powered;
      }
    }
  }
  
  // This function can be used to authenticate a users visit, for instance if you want a spash page
  // you would put this function reference into your header.php file and each time a new user
  // comes to any page on your site they are first re-directed to your splash page
  // be careful using this function because it will also restrict Google's index bots but more on the
  // work around for that at a later time when we get into sitemaps 
  // This function should only be used in your header.php file 
  function authenticate(){
    session_start();
  
    $verify = $_SESSION['verify'];
    
    if($verify != "true")
    {
      $verify = $_GET['verify'];
  
      if($verify != "true")
      {
        $link = painfo('url',false);
        header("Location: ".$link."splash.php");
      }
      else
      {
        $_SESSION['verify'] = "true";
      }
    }
  }
  
  // This function will show your header.php file inside of the file called from
  // you can also use something like include_once('header.php');
  // This can be used in any file
  function get_header() {
    // Find which theme we are using
    db_connect();
      $query = "SELECT themedir FROM pa_settings WHERE id = 1";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)) {
        $theme = $row['themedir'];
      }
    db_close();
    
    include_once("pa-content/themes/".$theme."/header.php");
  }
  
  // This function will show your footer.php file inside of the file called from
  // you can also use something like include_once('footer.php');
  // This can be used in any file
  function get_footer() {
    // Find which theme we are using
    db_connect();
      $query = "SELECT themedir FROM pa_settings WHERE id = 1";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)) {
        $theme = $row['themedir'];
      }
    db_close();
    
    include_once("pa-content/themes/".$theme."/footer.php");
  }
  
  // This function will display a specific thumbnail image of a movie file just pass it the movies id
  // Can be used on any page
  function show_single_thumb($before = '', $after = '', $id, $linked = true, $display = true) {
    db_connect();
      $query = "SELECT img,title FROM pa_videos WHERE id = $id";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result))
      {
        $img = $row['img'];
        $title = $row['title'];
      }
    db_close();
    
    // Form image tag
    if($linked == false && $display == true){
      $image = $before.'<img src="'.$img.'" alt="'.$title.'" />'.$after;
    
      echo $image;
    }
    elseif($linked == true && $display == true)
    {
      $link = painfo('url',false);
      $image = $before.'<a href="'.$link.'single.php?id='.$id.'"><img src="'.$img.'" alt="'.$title.'" /></a>'.$after;
    
      echo $image;
    }
    elseif($linked == true && $display == false)
    {
      $link = painfo('url',false);
      $image = $before.'<a href="'.$link.'single.php?id='.$id.'"><img src="'.$img.'" alt="'.$title.'" /></a>'.$after;
    
      return $image;
    }
    elseif($linked == false && $display == false)
    {
      $image = $before.'<img src="'.$img.'" alt="'.$title.'" />'.$after;
      
      return $image;
    }
  }
  
  // this function will list all the categories
  // can be used on any page
  function list_all_cats($before = '', $after = '', $link = true,  $display = true) {
    db_connect();
      $query = "SELECT categories FROM pa_cats";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result))
      {
        $categories[] = $row['categories'];
      }
    db_close();
    
    $count = count($categories);
    $a = 0;
    while($a < $count){
      if($display == true && $link == true){
        $link = painfo('url', false);
        $var = $before.'<a class="bold" href="'.$link.'search.php?cat=1&q='.$categories[$a].'">'.$categories[$a].'</a>'.$after;
        echo $var;
      }
      elseif($display == true && $link == false){
        echo $before.$categories[$a].$after;
      }
      elseif($display == false && $link == true){
        $link = painfo('url', false);
        $var = $before.'<a class="bold" href="'.$link.'search.php?cat=1&q='.$categories[$a].'">'.$categories[$a].'</a>'.$after;
        return $var;
      }
      elseif($display == false && $link == false){
        return $before.$categories[$a].$after;
      }
      $a++;
    }
  }

  // this function is used to display the video inside of a page
  // can only be used on the single.php page
  function embed($before = '', $after = '', $display = true) {
    $id = $_GET['id'];
    db_connect();
      $query = "SELECT embedCode FROM pa_videos WHERE id = $id";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result))
      {
        $embed = $row['embedCode'];
      }
    db_close();
    $embed = stripslashes($embed);
    
    if($display == true){
      echo $before.$embed.$after;
    }
    
    if($display == false){
      return $before.$embed.$after;
    }
  }
  
  // This category will create a list of thumbnail images, it comes with lots and lots of args
  // more on this later
  // can be used on any page
  function list_thumbs($before = '', $after = '', $num, $order = 'DESC', $linked = true, $display = true) {
    db_connect();
      $query = "SELECT id,img,title FROM pa_videos ORDER BY id $order LIMIT $num";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)) {
        $id[] = $row['id'];
        $img[] = $row['img'];
        $title[] = $row['title'];
      }
    db_close();
    
    // Count how many results there are
    $count = count($img);
    $a = 0;
    
    // Cycle through results and display them
    while($a < $count) {
      if($linked == true && $display == true) {
        $link = painfo('url', false);
        $tag = '<a href="'.$link.'single.php?id='.$id[$a].'"><img src="'.$img[$a].'" alt="'.$title[$a].'" />'.
        '</a>';
        
        echo $before.$tag.$after;
      }
      
      if($linked == false && $display == true) {
        $tag = '<img src="'.$img[$a].'" alt="'.$title[$a].'" />';
        echo $before.$tag.$after;
      }
      
      // Next Variation
      if($linked == true && $display == false) {
        $link = painfo('url', false);
        $tag = '<a href="'.$link.'single.php?id='.$id[$a].'"><img src="'.$img[$a].'" alt="'.$title[$a].'" />'.
        '</a>';
        
        return $before.$tag.$after;
      }
      
      if($linked == false && $display == false) {
        $tag = '<img src="'.$img[$a].'" alt="'.$title[$a].'" />';
        return $before.$tag.$after;
      }
      $a++;
    }
  }
  
  // This function will show a random thumbnail image of a movie file, good if used to show random videos
  // can be used on any page
  function show_rand_thumb($before = '', $after = '', $link = true, $display = true) {
    db_connect();
      $query = "SELECT img FROM pa_videos";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)){
        $img[] = $row['img'];
      }
    db_close();
    
    $count = count($img);

    $rand = mt_rand(1,$count);
    
    db_connect();
      $query = "SELECT * FROM pa_videos WHERE id = $rand";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)){
        $id = $row['id'];
        $imag = $row['img'];
        $title = $row['title'];
      }
    db_close();
    
    if(!$imag) {
      $rand = mt_rand(1,$count);
      
      db_connect();
        $query = "SELECT * FROM pa_videos WHERE id = $rand";
        $result = @mysql_query($query);
        
        while($row = @mysql_fetch_array($result)){
          $id = $row['id'];
          $imag = $row['img'];
          $title = $row['title'];
        }
      db_close();
    }
    
    if($display == true && $link == false){
      echo $before.'<img src="'.$imag.'" alt="'.$title.'" />'.$after;
    }
    elseif($display == false && $link == false)
    {
      $val = $before.'<img src="'.$imag.'" alt="'.$title.'" />';
      return $before.$val.$after;
    }
    elseif($display == true && $link == true)
    {
      $link = painfo('url', false);
      $val = '<a href="'.$link.'single.php?id='.$id.'"><img src="'.$imag.'" alt="'.$title.'" /></a>';
      echo $before.$val.$after;
    }
    elseif($display == false && $link == true)
    {
      $link = painfo('url', false);
      $val = '<a href="'.$link.'single.php?id='.$id.'"><img src="'.$imag.'" alt="'.$title.'" /></a>';
      return $before.$val.$after;
    }
  }
  
  // Displays the numeric ID of the current video. This tag can only be used on the single.php page.
  // can only be used on the single.php page
  function the_ID($display = true) {
    if($display == true) {
      echo $_GET['id'];
    }
    else
    {
      return $_GET['id'];
    }
  }
  
  // Displays or returns the title of the current video. This tag can only be used on the single.php page.
  // can only be used on the single.php page
  function the_title($before = '', $after = '', $display = true) {
    $id = $_GET['id'];
    db_connect();
      $query = "SELECT title FROM pa_videos WHERE id = $id";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)){
        $title = $row['title'];
      }
    db_close();
    
    if($display == true) {
      echo $before.$title.$after;
    }
    
    if($display == false) {
      return $before.$title.$after;
    }
  }
  
  // Displays the contents of the current video. This tag can only be used on the single.php page.
  function the_content($before = '', $after = '', $display = true) {
    $id = $_GET['id'];
    db_connect();
      $query = "SELECT description FROM pa_videos WHERE id = $id";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result))
      {
        $desc = $row['description'];
      }
    db_close();
    
    if($display == true){
      echo $before.$desc.$after;
    }
    
    if($display == false){
      return $before.$desc.$after;
    }
  }
  
  // Displays a link to the category or categories a post belongs to. 
  // This tag can only be used on the single.php page.
  function the_category($before = '', $after = '', $linked = false, $display = true) {
    $id = $_GET['id'];
    // find the websites name
    db_connect();
      $query = "SELECT category FROM pa_videos WHERE id = $id";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)) {
        $cat = $row['category'];
      }
    db_close();
    
    if($display == true && $linked == false){
      echo $before.$cat.$after;
    }
    elseif($display == false && $linked == false)
    {
      return $before.$cat.$after;
    }
    elseif($display == true && $linked == true)
    {
      $link = painfo('url', false);
      $subject = $cat;
      $replace = array(' ' => '');
      $reformed = strtr("$subject", $replace);
      echo $before.'<a href="'.$link.'search.php?q='.$reformed.'">'.$cat."</a>".$after;
    }
    elseif($display == false && $linked == true)
    {
      return $before.$cat.$after;
    }
  }
  
  // this template tag displays a link to the previous post which exists in chronological order from the current post.
  // can only be used in the single.php file
  function previous_post_link($before = '', $after = '', $link = true, $display = true) {
    $id = $_GET['id'];
    $id = $id - 1;
    if($id < 1){
      $id = 1;
    }
    db_connect();
      $query = "SELECT title FROM pa_videos WHERE id = $id";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)) {
        $title = $row['title'];
      }
    db_close();
    
    if($display == true && $link == true && isset($title)) {
      echo $before.'<a href="'.painfo('url').'?single.php?id='.$id.'">'.$title.'</a>'.$after;
    }
    
    if($display == false && $link == false && isset($title)) {
      return $before.$title.$after;
    }
  }
  
  // this template tag displays a link to the next post which exists in chronological order from the current post.
  // can only be used in the single.php file
  function next_post_link($before = '', $after = '', $link = true, $display = true) {
    $id = $_GET['id'];
    $id = $id + 1;
    if($id < 1){
      $id = 1;
    }
    db_connect();
      $query = "SELECT title FROM pa_videos WHERE id = $id";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)) {
        $title = $row['title'];
      }
    db_close();
    
    if($display == true && $link == true && isset($title)) {
      echo $before.'<a href="'.painfo('url').'?single.php?id='.$id.'">'.$title.'</a>'.$after;
    }
    
    if($display == false && $link == false && isset($title)) {
      return $before.$title.$after;
    }
  }
  
  // This function will show a related video to the viewers of the current video
  // Can only be used on the single.php page
  function show_related_thumb($before = '', $after = '', $num = '1', $term = '', $display = true) {
    $id = $_GET['id'];
    db_connect();
      $query = "SELECT * FROM pa_videos WHERE title LIKE '%$term%' OR description LIKE '%$term%' LIMIT $num";
      $result = @mysql_query($query);
      
      while($row = @mysql_fetch_array($result)) {
        if($display == true) {
          $link = painfo('url', false);
          echo $before.'<a href="'.$link.'single.php?id='.$row['id'].'"><img src="'.$row['img'].'" alt="'.$row['title'].'" /></a>'.$after;
        }
        else
        {
          return $before.'<a href="'.$link.'single.php?id='.$row['id'].'"><img src="'.$row['img'].'" alt="'.$row['title'].'" /></a>'.$after;
        }
      }
    db_close();
  }
  
  function search_results($type = '', $show = false, $display = true) {
    if($_GET['q']){
      // Get the search results
      $limit = 35; 
      
      // Get search string
      $q = $_GET['q'];
      
      // Is this a category search
      $cat = $_GET['cat'];
      
      //connect to your database
      db_connect();                  
        // Build SQL Query
        if($cat != 1) {
          $query = "SELECT * FROM pa_videos WHERE title LIKE '%$q%'";
        }
        else
        {
          $query = "SELECT * FROM pa_videos WHERE category = '$q'";
        }
        
        // How many results are there in the database
        $numresults = mysql_query($query);
        $numrows = mysql_num_rows($numresults);
        $numrows--;
      // close data connection
      db_close();
          
      // next determine if s has been passed to script, if not use 1
      $s = $_GET['s'];
      
      if(!$s) 
      {   
        $s = 1;
      }
      else
      {
        $s = $_GET['s'];
      }

      // Build new query
      $query .= " LIMIT $s,$limit";          

      // connect to database
      db_connect();
      
      // Get results
      $result = @mysql_query($query);
      $tableRow = 0;
      $link = painfo('url',false);
      
      // display results
      if($show == true) {
        while($row = @mysql_fetch_array($result))
        {      
          if($tableRow == 0){
            echo '<tr>';
          }
          
          $title = $row['title'];
          $id = $row['id'];
          $img = $row['img'];
          
          echo '<td><a href="'.$link.'single.php?id='.$id.'"><img src="'.$img.'" alt="'.$title.'" /></a>'.
          '</td>';
          
          $tableRow++;
          
          if($tableRow == 5) {
            echo "</tr>";
            $tableRow = 0;
          }
        }
        
        if($tableRow < 7) {
          echo "</tr>";
        }
      }

      // close database connection
      db_close();
      
      if($type == 'paging') {
        // Get our current page value
        $currPage = ($s / $limit) + 1;
        $currPage = round($currPage);
        
        // calculate number of pages
        $pages = intval($numrows / $limit);

        // $pages now contains int of pages needed unless there is a remainder from division
        if ($numrows % $limit) {
          // has remainder so add one page
          $pages++;
        }
        
        // next we need to do the links to other results
        if($currPage > 1) { // bypass PREV link if s is 0
          // Get the previous records
          $prevs = $s - $limit;
          
          // Make sure $prevs is not below 1
          if($prevs < 1){
            $prevs = 1;
          }
          
          // Show the previous link
          if($currPage < $pages && $pages != 1){
            if($cat != 1) {
              echo '<tr><td><a href="'.$link.'search.php?q='.$q.'&s='.$prevs.'">&laquo;'.
              'Prev 20</a></td>';
            }
            else
            {
              echo '<tr><td><a href="'.$link.'search.php?cat=1&q='.$q.'&s='.$prevs.'">&laquo;'.
              'Prev 20</a></td>';
            }
          }
          else
          {
            if($cat != 1) {
              echo '<tr><td><a href="'.$link.'search.php?q='.$q.'&s='.$prevs.'">&laquo; '. 
              'Prev 20</a></td></tr>';
            }
            else
            {
              echo '<tr><td><a href="'.$link.'search.php?cat=1&q='.$q.'&s='.$prevs.'">&laquo; '. 
              'Prev 20</a></td></tr>';
            }
          }
        }

        // check to see if last page
        if($currPage < $pages && $pages != 1) {
          // not last page so give NEXT link
          $news = $s + $limit;
          
          // echo the link link button
          if($currPage > 1) {
            if($cat != 1) {
              echo '<td><a href="'.$link.'search.php?q='.$q.'&s='.$news.'">Next 20 &raquo;</a></td></tr>';
            }
            else
            {
              echo '<td><a href="'.$link.'search.php?cat=1&q='.$q.'&s='.$news.'">Next 20 &raquo;</a></td></tr>';
            }
          }
          else
          {
            if($cat != 1) {
              echo '<tr><td><a href="'.$link.'search.php?q='.$q.'&s='.$news.'">Next 20 &raquo;</a></td></tr>';
            }
            else
            {
              echo '<tr><td><a href="'.$link.'search.php?cat=1&q='.$q.'&s='.$news.'">Next 20 &raquo;</a></td></tr>';
            }
          }
          
        }
        
        // Display a few input stats
        $a = $s + $limit;
        if ($a > $numrows) 
        { 
          $a = $numrows; 
        }
        echo "<tr><td>Showing results $s to $a of $numrows</td></tr>";
      }
      
      if($type == 'total') {
        echo $numrows;
      }
      
      // Return The Search String
      if($type == 'string'){
        if($display == true) {
          echo $_GET['q'];
        }
        else
        {
          return $_GET['q'];
        }
      }
    }
    else
    {
      if($display == true) {
          echo "Invalid Search";
        }
        else
        {
          return "Invalid Search";
        }
    }
  }
?>
