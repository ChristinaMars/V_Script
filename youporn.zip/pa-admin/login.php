<?php /* This file encoded by Raizlabs PHP Obfuscator http://www.raizlabs.com/software */ ?>
<?php     include_once('../pa-config.php');        if($_GET['inval'] == true)    {      $RB5ADDE8D7D7412251F47419FE9BF51A7 = "You Are Not Logged In. Please Login Now!";    }        if($_GET['forgot'] == true)    {      $RB5ADDE8D7D7412251F47419FE9BF51A7 = "A New Password Has Been Sent To ".$_GET['email']."!";    }        if($_GET['logout'] == true)    {      $RB5ADDE8D7D7412251F47419FE9BF51A7 = "You Have Successfully Logged Out!";    }        if($_POST)    {       db_connect();        $RE91192A00FF990477EE414AD5D708F08 = "SELECT * FROM pa_settings";        $R679E9B9234E2062F809DBD3325D37FB6 = @mysql_query($RE91192A00FF990477EE414AD5D708F08);                while($R4EEB713E57BBAAF1217CF39632604473 = @mysql_fetch_array($R679E9B9234E2062F809DBD3325D37FB6))        {          $RE0D5EDB560A26D4E1BECD832EA026E32 = $R4EEB713E57BBAAF1217CF39632604473['username'];          $RA7039E011D8491F313BCD5E4D1DC2253 = $R4EEB713E57BBAAF1217CF39632604473['passencrypt'];        }      db_close();            $R018BDC892A51BE987909D3C80169099B = trim($_POST['user']);      $R8A699776DB9CAAD380E8453DB24380CA = trim($_POST['pass']);      $R8A699776DB9CAAD380E8453DB24380CA = md5($R8A699776DB9CAAD380E8453DB24380CA);            if($R018BDC892A51BE987909D3C80169099B != $RE0D5EDB560A26D4E1BECD832EA026E32)      {        $RB5ADDE8D7D7412251F47419FE9BF51A7 = "Invalid Username.";      }            if($R8A699776DB9CAAD380E8453DB24380CA != $RA7039E011D8491F313BCD5E4D1DC2253)      {        $RB5ADDE8D7D7412251F47419FE9BF51A7 = "Invalid Password.";      }            if($R018BDC892A51BE987909D3C80169099B == $RE0D5EDB560A26D4E1BECD832EA026E32 && $R8A699776DB9CAAD380E8453DB24380CA == $RA7039E011D8491F313BCD5E4D1DC2253)      {        if(empty($RB5ADDE8D7D7412251F47419FE9BF51A7))        {          session_start();          $_SESSION['user'] = $RE0D5EDB560A26D4E1BECD832EA026E32;          header("Location: http://".$_SERVER['HTTP_HOST']."/pa-admin/index.php");        }        else        {          $RB5ADDE8D7D7412251F47419FE9BF51A7 = "Unknown Error Please Try Again.";        }      }    }      ?>

<html>
  <head>
    <title>XpModderz Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="<?php echo painfo('url'); ?>pa-admin/css/style.css" />
    <?php         echo "<script type='text/javascript' src='".painfo('url')."pa-admin/js/admin.js'></script>";      ?>
    
  </head>
  
  <body>
  <center>
    <div id="adminheader">
      &nbsp;
    </div>
    
    <div id="content">
    <form method="post" action="http://<?php echo $_SERVER['HTTP_HOST']."/pa-admin/login.php"; ?>" name="login">
      <table align="center" cellspacing="0" cellpadding="0">
        <tr>
          <td>
            <div id="errors">
              <?php if($RB5ADDE8D7D7412251F47419FE9BF51A7){echo '<center><font color="#FF1A00">'.$RB5ADDE8D7D7412251F47419FE9BF51A7.'</font></center>';} ?>
            </div>
          </td>
        </tr>
        
        <tr>
          <td>
            <div class="adminp">
              <b>Username: </b> <input type="text" name="user" value="" size="40" />     
            </div>
          </td>
        </tr>
        
        <tr>
          <td>
            <div class="adminp">
              <b>Password: </b> <input type="password" name="pass" value="" size="40" /> 
            </div>
          </td>
        </tr>
        
        <tr>
          <td>
            <center>
              <a href="http://<?php echo $_SERVER['HTTP_HOST']."/pa-admin/forgot.php" ?>">Forgot Your Password? </a>
            </center>
          </td>
        </tr>
        
        <tr>
          <td>
            <div class="adminsub">
              <input type="submit" name="login" value="Login" />
            </div>
          </td>
        </tr>
      </table>
    </form>
    </div>
    
    <div id="footer"> <div style="padding-top:35px;">
      <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" width="270" height="203" id="anitextMov">
        <param name="movie" value="anitext.swf">
        <param name="quality" value="high">
        <param name="loop" value="false">
        <param name="bgcolor" value="#000000">
        <embed src="anitext.swf" quality="high" bgcolor="#000000" width="270" height="203" name="anitextMov" align="center" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed>
      </object> 
      </div>
    </div>
  </center>
  </body>
</html>
