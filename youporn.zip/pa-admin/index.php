<?php /* This file encoded by Raizlabs PHP Obfuscator http://www.raizlabs.com/software */ ?>
<?php            session_start();        if(empty($_SESSION['user']))    {      header("Location: http://".$_SERVER['HTTP_HOST']."/pa-admin/login.php?inval=true");    }        if($_GET['signout'] == 1) {           unset($_SESSION['user']);      header("Location: http://".$_SERVER['HTTP_HOST']."/pa-admin/login.php?logout=true");    }                 include_once('../pa-config.php');         if($_GET['options'] == 1){      db_connect();        $RE91192A00FF990477EE414AD5D708F08 = "SELECT * FROM pa_settings";        $R679E9B9234E2062F809DBD3325D37FB6 = @mysql_query($RE91192A00FF990477EE414AD5D708F08);                while($R4EEB713E57BBAAF1217CF39632604473 = @mysql_fetch_array($R679E9B9234E2062F809DBD3325D37FB6)){          $R811C2478F322F43A2B4C82E3237190C5 = $R4EEB713E57BBAAF1217CF39632604473['sitename'];          $R6E4F14B335243BE656C65E3ED9E1B115 = $R4EEB713E57BBAAF1217CF39632604473['url'];          $REBF2CBC420EBA1C0735E00ADC8973512 = $R4EEB713E57BBAAF1217CF39632604473['email'];          $username = $R4EEB713E57BBAAF1217CF39632604473['username'];        }      db_close();    }           if($_GET['delete'] == 1){      db_connect();        $R3584859062EA9ECFB39B93BFCEF8E869 = $_GET['id'];        $RE91192A00FF990477EE414AD5D708F08 = "DELETE FROM pa_videos WHERE id = $R3584859062EA9ECFB39B93BFCEF8E869 LIMIT 1";        @mysql_query($RE91192A00FF990477EE414AD5D708F08);      db_close();    }           if($_GET['editpost'] == 1) {      $R06C518F70E97B19C7EC907F36542CE6E = $_POST["title"];      $R3BCCCF8B7680DEA728EB9FA442774AFD = $_POST['embed'];      $RC5934A886BA9823EDE289AB2FD67CED1 = $_POST['description'];      $R6A39AF2A2BC3EA151BD12B1462BA22E9 = $_POST['thumb'];      $R3584859062EA9ECFB39B93BFCEF8E869 = $_POST['id'];      $RCB6CF74D12D3949F4F3C570ECE4B9CB5 = $_POST['cat'];            $R3BCCCF8B7680DEA728EB9FA442774AFD = stripslashes($R3BCCCF8B7680DEA728EB9FA442774AFD);           $R52D5B5E885B21331CFD2304BE571DE0B = 0;      $RA1D44C0654A40984A103C270FFB9BF33 = count($RCB6CF74D12D3949F4F3C570ECE4B9CB5);      while($R52D5B5E885B21331CFD2304BE571DE0B < $RA1D44C0654A40984A103C270FFB9BF33) {        if($RCB6CF74D12D3949F4F3C570ECE4B9CB5[$R52D5B5E885B21331CFD2304BE571DE0B] == 1) {          $RCB6CF74D12D3949F4F3C570ECE4B9CB5[] = $RCB6CF74D12D3949F4F3C570ECE4B9CB5[$R52D5B5E885B21331CFD2304BE571DE0B];        }        $R52D5B5E885B21331CFD2304BE571DE0B++;      }                 $RFB90CBF44194245276E324A9F953D2A3 = count($RCB6CF74D12D3949F4F3C570ECE4B9CB5);            if($RFB90CBF44194245276E324A9F953D2A3 > 1){        $RB5ADDE8D7D7412251F47419FE9BF51A7 = '<font color="#FF1A00"><b>You Can Only Select 1 Category Per Post.</b></font>';      }      elseif($RFB90CBF44194245276E324A9F953D2A3 != 1)      {        $RCB6CF74D12D3949F4F3C570ECE4B9CB5[0] = "Uncategorized";      }            if(!$RB5ADDE8D7D7412251F47419FE9BF51A7){        db_connect();          $RE91192A00FF990477EE414AD5D708F08 = "UPDATE pa_videos SET title = '".mysql_real_escape_string($R06C518F70E97B19C7EC907F36542CE6E)."', embedCode = '".mysql_real_escape_string($R3BCCCF8B7680DEA728EB9FA442774AFD)."', img = '".mysql_real_escape_string($R6A39AF2A2BC3EA151BD12B1462BA22E9)."', description = '".mysql_real_escape_string($RC5934A886BA9823EDE289AB2FD67CED1)."', category = '".mysql_real_escape_string($RCB6CF74D12D3949F4F3C570ECE4B9CB5[0])."' WHERE id = $R3584859062EA9ECFB39B93BFCEF8E869";          @mysql_query($RE91192A00FF990477EE414AD5D708F08);        db_close();                $RB5ADDE8D7D7412251F47419FE9BF51A7 = '<font color="#008C00"><b>The Post Was Successfully Edited.</b></font>';      }    }           if($_GET['newpost'] == 1){      $R06C518F70E97B19C7EC907F36542CE6E = $_POST["title"];      $R3BCCCF8B7680DEA728EB9FA442774AFD = $_POST['embed'];      $RC5934A886BA9823EDE289AB2FD67CED1 = $_POST['description'];      $R6A39AF2A2BC3EA151BD12B1462BA22E9 = $_POST['thumb'];      $RCB6CF74D12D3949F4F3C570ECE4B9CB5 = $_POST['cat'];      $R7B5C40C2661BE2363CC09FDC872AEB44 = "MyPost";            if(!$R06C518F70E97B19C7EC907F36542CE6E) {        $R5605B9058F5CC6709169824676373BE6 = '<font color="#FF1A00"><b>You Must Enter A Title.</b></font>';      }            if(!$R3BCCCF8B7680DEA728EB9FA442774AFD) {        $R5605B9058F5CC6709169824676373BE6 = '<font color="#FF1A00"><b>You Must Enter Some Embed Code.</b></font>';      }            if(!$R6A39AF2A2BC3EA151BD12B1462BA22E9) {        $R5605B9058F5CC6709169824676373BE6 = '<font color="#FF1A00"><b>You Must Enter A Valid Thumbnail URL.</b></font>';      }                 $R52D5B5E885B21331CFD2304BE571DE0B = 0;      $RA1D44C0654A40984A103C270FFB9BF33 = count($RCB6CF74D12D3949F4F3C570ECE4B9CB5);      while($R52D5B5E885B21331CFD2304BE571DE0B < $RA1D44C0654A40984A103C270FFB9BF33) {        if($RCB6CF74D12D3949F4F3C570ECE4B9CB5[$R52D5B5E885B21331CFD2304BE571DE0B] == 1) {          $RCB6CF74D12D3949F4F3C570ECE4B9CB5[] = $RCB6CF74D12D3949F4F3C570ECE4B9CB5[$R52D5B5E885B21331CFD2304BE571DE0B];        }        $R52D5B5E885B21331CFD2304BE571DE0B++;      }                 $RFB90CBF44194245276E324A9F953D2A3 = count($RCB6CF74D12D3949F4F3C570ECE4B9CB5);            if($RFB90CBF44194245276E324A9F953D2A3 > 1){        $R5605B9058F5CC6709169824676373BE6 = '<font color="#FF1A00"><b>You Can Only Select 1 Category Per Post.</b></font>';      }      elseif($RFB90CBF44194245276E324A9F953D2A3 != 1)      {        $RCB6CF74D12D3949F4F3C570ECE4B9CB5[0] = "Uncategorized";      }            if(!$R5605B9058F5CC6709169824676373BE6){        db_connect();          $RE91192A00FF990477EE414AD5D708F08 = "INSERT INTO pa_videos (source,title,embedCode,img,description,category) VALUES ('$R7B5C40C2661BE2363CC09FDC872AEB44','".mysql_real_escape_string($R06C518F70E97B19C7EC907F36542CE6E)."','".mysql_real_escape_string($R3BCCCF8B7680DEA728EB9FA442774AFD)."','".mysql_real_escape_string($R6A39AF2A2BC3EA151BD12B1462BA22E9)."','".mysql_real_escape_string($RC5934A886BA9823EDE289AB2FD67CED1)."','".mysql_real_escape_string($RCB6CF74D12D3949F4F3C570ECE4B9CB5[0])."');";          @mysql_query($RE91192A00FF990477EE414AD5D708F08);        db_close();                $R5605B9058F5CC6709169824676373BE6 = '<font color="#008C00"><b>The Post Was Successfully Created.</b></font>';                $R06C518F70E97B19C7EC907F36542CE6E = "";        $R3BCCCF8B7680DEA728EB9FA442774AFD = "";        $RC5934A886BA9823EDE289AB2FD67CED1 = "";        $R6A39AF2A2BC3EA151BD12B1462BA22E9 = "";      }    }           if($_GET['postoptions'] == 1) {      $R811C2478F322F43A2B4C82E3237190C5 = $_POST['sitename'];      $R6E4F14B335243BE656C65E3ED9E1B115 = $_POST['url'];      $REBF2CBC420EBA1C0735E00ADC8973512 = $_POST['email'];      $username = $_POST['username'];      $RB148E7F41FDC3BE4B14E8D17E068BBAD = $_POST['pass'];      $R401C450BE2D97347012C897224D9102F = $_POST['passconfirm'];                 if(!$R811C2478F322F43A2B4C82E3237190C5){        $RC166A870198FA39B6D136B6A17A72BF5 = '<font color="#FF1A00"><b>Sitename Is Required.</font></b>';      }                 if(!$R6E4F14B335243BE656C65E3ED9E1B115){        $RC166A870198FA39B6D136B6A17A72BF5 = '<font color="#FF1A00"><b>Website URL Is Required.</font></b>';      }                 if(!$username){        $RC166A870198FA39B6D136B6A17A72BF5 = '<font color="#FF1A00"><b>Username Is Required.</font></b>';      }                 if($RB148E7F41FDC3BE4B14E8D17E068BBAD) {        if($RB148E7F41FDC3BE4B14E8D17E068BBAD != $R401C450BE2D97347012C897224D9102F){          $RC166A870198FA39B6D136B6A17A72BF5 = '<font color="#FF1A00"><b>Your Passwords Do Not Match.</font></b>';        }        else        {                   $RB148E7F41FDC3BE4B14E8D17E068BBAD = md5($RB148E7F41FDC3BE4B14E8D17E068BBAD);        }      }                 if(!$RC166A870198FA39B6D136B6A17A72BF5){        db_connect();          if($RB148E7F41FDC3BE4B14E8D17E068BBAD){            $RE91192A00FF990477EE414AD5D708F08 = "UPDATE pa_settings SET sitename = '$R811C2478F322F43A2B4C82E3237190C5', url = '$R6E4F14B335243BE656C65E3ED9E1B115', email = '$REBF2CBC420EBA1C0735E00ADC8973512', username = '$username', passencrypt = '$RB148E7F41FDC3BE4B14E8D17E068BBAD' WHERE id = 1";          }          else          {            $RE91192A00FF990477EE414AD5D708F08 = "UPDATE pa_settings SET sitename = '$R811C2478F322F43A2B4C82E3237190C5', url = '$R6E4F14B335243BE656C65E3ED9E1B115', email = '$REBF2CBC420EBA1C0735E00ADC8973512', username = '$username' WHERE id = 1";                  }                    @mysql_query($RE91192A00FF990477EE414AD5D708F08);          $RC166A870198FA39B6D136B6A17A72BF5 = '<font color="#008C00"><b>Your Options Have Been Successfully Updated.</b></font>';        db_close();      }    }           if($_GET['settheme'] == 1) {      $R714CA9EB87223AD2D6815F90173FDE78 = $_GET['dir'];      db_connect();        $RE91192A00FF990477EE414AD5D708F08 = "UPDATE pa_settings SET themedir = '".mysql_real_escape_string($R714CA9EB87223AD2D6815F90173FDE78)."'";        @mysql_query($RE91192A00FF990477EE414AD5D708F08);      db_close();    }  ?>

<html>
  <head>
    <title>XpModderz Admin Panel</title>
    <link rel="stylesheet" type="text/css" href="<?php painfo('url'); ?>pa-admin/css/style.css" />    
  </head>
  
  <body>
  <center>
    <div id="adminheader">
      &nbsp;
    </div>
    
    <div id="nav">
      <a href="<?php painfo('url'); ?>pa-admin/index.php?write=1">Write</a> | <a href="<?php painfo('url'); ?>pa-admin/index.php?manage=1">Manage</a> | <a href="<?php painfo('url'); ?>pa-admin/index.php?themes=1">Presentation</a> | <a href="<?php painfo('url'); ?>pa-admin/index.php?options=1">Options</a> | <a target="_blank" href="mailto:cornetofreak@gmail.com">Help</a> | <a href="<?php painfo('url'); ?>pa-admin/index.php?signout=1">Signout</a>
    </div>
    
    <div id="content">
      <?php           if($_GET['write'] == 1 || !empty($R5605B9058F5CC6709169824676373BE6) || empty($_GET)) :        ?>
      <div class="dash">
      
        <?php             if($R5605B9058F5CC6709169824676373BE6){              echo "<center>".$R5605B9058F5CC6709169824676373BE6."</center><br />";            }          ?>
        
        <h2>New Post</h2>
        
        <form method="post" action="http://<?php echo $_SERVER['HTTP_HOST']."/pa-admin/index.php?newpost=1"; ?>" name="editpost">
        
        <div class="writeRight">
          <h2>Categories</h2>
          <ul>
          <?php               F3A2728D0E3CD127E34A8213A7076A110();            ?>
          </ul>
        </div>
        
        <table cellpadding="0" cellspacing="0">
          <tr>
            <td>
              <div class="adminp">
                <b>Title: </b> <br />
                <input type="text" name="title" value="<?php if($R06C518F70E97B19C7EC907F36542CE6E){ echo $R06C518F70E97B19C7EC907F36542CE6E; } ?>" size="60" />
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                  <b>Embed Code: </b> <br />
                  <textarea name="embed" cols="55" rows="10"><?php if($R3BCCCF8B7680DEA728EB9FA442774AFD){ echo $R3BCCCF8B7680DEA728EB9FA442774AFD; } ?></textarea>
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                <b>Description: </b> <br />
                <textarea name="description" cols="55" rows="10"><?php if($RC5934A886BA9823EDE289AB2FD67CED1){ echo $RC5934A886BA9823EDE289AB2FD67CED1; } ?></textarea>
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                <b>Thumbnail Link: </b> <br />
                <input type="text" name="thumb" value="<?php if($R6A39AF2A2BC3EA151BD12B1462BA22E9){ echo $R6A39AF2A2BC3EA151BD12B1462BA22E9; } ?>" size="60" />
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                <input type="submit" name="button" value="Make Post" />
              </div>
            </td>
          </tr>
        </table>
      </form>
      </div>
      <?php           endif;          if($_GET['edit'] == 1 || !empty($RB5ADDE8D7D7412251F47419FE9BF51A7)) :            db_connect();              if(empty($RB5ADDE8D7D7412251F47419FE9BF51A7)){                $R3584859062EA9ECFB39B93BFCEF8E869 = $_GET['id'];              }              $RE91192A00FF990477EE414AD5D708F08 = "SELECT * FROM pa_videos WHERE id = $R3584859062EA9ECFB39B93BFCEF8E869";              $R679E9B9234E2062F809DBD3325D37FB6 = @mysql_query($RE91192A00FF990477EE414AD5D708F08);                            while($R4EEB713E57BBAAF1217CF39632604473 = @mysql_fetch_array($R679E9B9234E2062F809DBD3325D37FB6)) {                $R06C518F70E97B19C7EC907F36542CE6E = $R4EEB713E57BBAAF1217CF39632604473['title'];                $R3BCCCF8B7680DEA728EB9FA442774AFD = $R4EEB713E57BBAAF1217CF39632604473['embedCode'];                $RC5934A886BA9823EDE289AB2FD67CED1 = $R4EEB713E57BBAAF1217CF39632604473['description'];                $R6A39AF2A2BC3EA151BD12B1462BA22E9 = $R4EEB713E57BBAAF1217CF39632604473['img'];                $RCB6CF74D12D3949F4F3C570ECE4B9CB5 = $R4EEB713E57BBAAF1217CF39632604473['category'];                                $R3BCCCF8B7680DEA728EB9FA442774AFD = stripslashes($R3BCCCF8B7680DEA728EB9FA442774AFD);              }            db_close();        ?>
      <div class="dash">
        
        <?php             if($RB5ADDE8D7D7412251F47419FE9BF51A7){              echo "<center>".$RB5ADDE8D7D7412251F47419FE9BF51A7."</center><br />";            }          ?>

        <h2>Edit Post</h2>

        <form method="post" action="http://<?php echo $_SERVER['HTTP_HOST']."/pa-admin/index.php?editpost=1"; ?>" name="editpost">
        
        <div class="writeRight">
          <h2>Categories</h2>
          <ul>
          <?php               FCB8065838BC38B9467571F3B5D5A53AD($RCB6CF74D12D3949F4F3C570ECE4B9CB5);            ?>
          </ul>
        </div>
        
        <input type="hidden" name="id" value="<?php echo $R3584859062EA9ECFB39B93BFCEF8E869; ?>" />
        <table cellpadding="0" cellspacing="0">
          <tr>
            <td>
              <div class="adminp">
                <b>Title: </b> <br />
                <input type="text" name="title" value="<?php echo $R06C518F70E97B19C7EC907F36542CE6E; ?>" size="60" />
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                  <b>Embed Code: </b> <br />
                  <textarea name="embed" cols="55" rows="10"><?php echo $R3BCCCF8B7680DEA728EB9FA442774AFD; ?></textarea>
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                <b>Description: </b> <br />
                <textarea name="description" cols="55" rows="10"><?php echo $RC5934A886BA9823EDE289AB2FD67CED1; ?></textarea>
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                <b>Thumbnail Link: </b> <br />
                <input type="text" name="thumb" value="<?php echo $R6A39AF2A2BC3EA151BD12B1462BA22E9; ?>" size="60" />
              </div>
            </td>
          </tr>
          
          <tr>
            <td>
              <div class="adminp">
                <input type="submit" name="button" value="Edit Post" />
              </div>
            </td>
          </tr>
        </table>
      </form>
      </div>
      <?php           endif;            if($_GET['manage'] == 1) :        ?>
      <div class="dash">
        <h2>Manage Posts</h2>

        <table width="98%" align="center" cellpadding="3" cellspacing="5">
          <tr bgcolor="#dfdfdf">
            <td>
              <b>ID</b>
            </td>
            
            <td>
              <b>Source</b>
            </td>
            
            <td>
              <b>Title</b>
            </td>
            
            <td>
              <b>Categories</b>
            </td>
            
            <td>
              <b>&nbsp;</b>
            </td>
            
            <td>
              <b>&nbsp;</b>
            </td>
            
            <td>
              <b>&nbsp;</b>
            </td>
          </tr>
          
          <?php                              $RFED47D15719EF82BD3F83B580230DA5B = 19;                                          db_connect();                                                     $RE91192A00FF990477EE414AD5D708F08 = "SELECT * FROM pa_videos";                                         $R5282D47CB7A65D5474C44FAA2CF76EB0 = mysql_query($RE91192A00FF990477EE414AD5D708F08);              $RE156F1239E15E72C0FBFC48503804574 = mysql_num_rows($R5282D47CB7A65D5474C44FAA2CF76EB0);              $RE156F1239E15E72C0FBFC48503804574--;                           db_close();                                         $R3CB9CDAED257453CFA56B9EF81B44C57 = $_GET['s'];                            if(!$R3CB9CDAED257453CFA56B9EF81B44C57)               {                   $R3CB9CDAED257453CFA56B9EF81B44C57 = 1;              }              else              {                $R3CB9CDAED257453CFA56B9EF81B44C57 = $_GET['s'];              }                             $RE91192A00FF990477EE414AD5D708F08 .= " LIMIT $R3CB9CDAED257453CFA56B9EF81B44C57,$RFED47D15719EF82BD3F83B580230DA5B";                                                   db_connect();                                         $R679E9B9234E2062F809DBD3325D37FB6 = @mysql_query($RE91192A00FF990477EE414AD5D708F08);              $RAE7FB3037B681EA966AFB45E63C56565 = 0;                                         while($R4EEB713E57BBAAF1217CF39632604473 = @mysql_fetch_array($R679E9B9234E2062F809DBD3325D37FB6))              {                if($RAE7FB3037B681EA966AFB45E63C56565 == 0){                  echo '<tr bgcolor="#f1f1f1">';                  $RAE7FB3037B681EA966AFB45E63C56565 = 1;                }                else                {                  echo '<tr bgcolor="#ffffff">';                  $RAE7FB3037B681EA966AFB45E63C56565 = 0;                }                                $R06C518F70E97B19C7EC907F36542CE6E = $R4EEB713E57BBAAF1217CF39632604473['title'];                $R3584859062EA9ECFB39B93BFCEF8E869 = $R4EEB713E57BBAAF1217CF39632604473['id'];                $R7B5C40C2661BE2363CC09FDC872AEB44 = $R4EEB713E57BBAAF1217CF39632604473['source'];                $RCB6CF74D12D3949F4F3C570ECE4B9CB5 = $R4EEB713E57BBAAF1217CF39632604473['category'];                                echo '<td>'.$R3584859062EA9ECFB39B93BFCEF8E869.'</td>'.                     '<td>'.$R7B5C40C2661BE2363CC09FDC872AEB44.'</td>'.                     '<td>'.$R06C518F70E97B19C7EC907F36542CE6E.'</td>'.                     '<td>'.$RCB6CF74D12D3949F4F3C570ECE4B9CB5.'</td>'.                     '<td><a href="http://'.$_SERVER['HTTP_HOST'].'/single.php?id='.$R3584859062EA9ECFB39B93BFCEF8E869.'">View</a></td>'.                     '<td><a href="http://'.$_SERVER['HTTP_HOST'].'/pa-admin/index.php?edit=1&id='.$R3584859062EA9ECFB39B93BFCEF8E869.'">Edit</a></td>'.                     '<td><a href="http://'.$_SERVER['HTTP_HOST'].'/pa-admin/index.php?manage=1&delete=1&id='.$R3584859062EA9ECFB39B93BFCEF8E869.'">Delete</a></td></tr>';              }                                         db_close();            ?>
        </table>
        
        <table align="center" cellpadding="3" cellspacing="5">
        <?php                        $R70E080D0667DFB43A9761F652283B472 = ($R3CB9CDAED257453CFA56B9EF81B44C57 / $RFED47D15719EF82BD3F83B580230DA5B) + 1;            $R70E080D0667DFB43A9761F652283B472 = round($R70E080D0667DFB43A9761F652283B472);                                   $RCDFB3313F5706C6951E32E3AB8CF5FF0 = intval($RE156F1239E15E72C0FBFC48503804574 / $RFED47D15719EF82BD3F83B580230DA5B);                         if ($RE156F1239E15E72C0FBFC48503804574 % $RFED47D15719EF82BD3F83B580230DA5B) {                           $RCDFB3313F5706C6951E32E3AB8CF5FF0++;            }                                   if($R70E080D0667DFB43A9761F652283B472 > 1) {                           $RD3A9CF2A7B8CD705235F50667E5FDE8B = $R3CB9CDAED257453CFA56B9EF81B44C57 - $RFED47D15719EF82BD3F83B580230DA5B;                                         if($RD3A9CF2A7B8CD705235F50667E5FDE8B < 1){                $RD3A9CF2A7B8CD705235F50667E5FDE8B = 1;              }                                         if($R70E080D0667DFB43A9761F652283B472 < $RCDFB3313F5706C6951E32E3AB8CF5FF0 && $RCDFB3313F5706C6951E32E3AB8CF5FF0 != 1){                echo '<tr><td><a href="http://'.$_SERVER['HTTP_HOST'].'/pa-admin/index.php?manage=1&s='.$RD3A9CF2A7B8CD705235F50667E5FDE8B.'">&laquo;'.                'Prev 20</a></td>';              }              else              {                echo "<tr><td><a href=\"http://".$_SERVER['HTTP_HOST']."/pa-admin/index.php?manage=1&s=$RD3A9CF2A7B8CD705235F50667E5FDE8B\">&laquo; ".                 'Prev 20</a></td></tr>';              }            }                         if($R70E080D0667DFB43A9761F652283B472 < $RCDFB3313F5706C6951E32E3AB8CF5FF0 && $RCDFB3313F5706C6951E32E3AB8CF5FF0 != 1) {                           $R4F5E60B211034CF2F8217DCF9A824C8A = $R3CB9CDAED257453CFA56B9EF81B44C57 + $RFED47D15719EF82BD3F83B580230DA5B;                                         if($R70E080D0667DFB43A9761F652283B472 > 1) {                echo "<td><a href=\"$RBD959A692CCA6F0F30140AA236844647?manage=1&s=$R4F5E60B211034CF2F8217DCF9A824C8A\">Next 20 &raquo;</a></td></tr>";              }              else              {                echo "<tr><td><a href=\"$RBD959A692CCA6F0F30140AA236844647?manage=1&s=$R4F5E60B211034CF2F8217DCF9A824C8A\">Next 20 &raquo;</a></td></tr>";              }                          }                                   $R52D5B5E885B21331CFD2304BE571DE0B = $R3CB9CDAED257453CFA56B9EF81B44C57 + $RFED47D15719EF82BD3F83B580230DA5B;            if ($R52D5B5E885B21331CFD2304BE571DE0B > $RE156F1239E15E72C0FBFC48503804574)             {               $R52D5B5E885B21331CFD2304BE571DE0B = $RE156F1239E15E72C0FBFC48503804574;             }            echo "<tr><td>Showing results $R3CB9CDAED257453CFA56B9EF81B44C57 to $R52D5B5E885B21331CFD2304BE571DE0B of $RE156F1239E15E72C0FBFC48503804574</td></tr>";          ?>
        </table>
      </div>
      <?php           endif;            if($_GET['themes'] == 1 || $_GET['settheme'] == 1) :        ?>
      <div class="dash">
      <?php                    db_connect();            $RE91192A00FF990477EE414AD5D708F08 = "SELECT themedir FROM pa_settings WHERE id = 1";            $R679E9B9234E2062F809DBD3325D37FB6 = @mysql_query($RE91192A00FF990477EE414AD5D708F08);                        while($R4EEB713E57BBAAF1217CF39632604473 = @mysql_fetch_array($R679E9B9234E2062F809DBD3325D37FB6)) {              $RF5AA909E0F4D8FA1B9F8B79D50267836 = $R4EEB713E57BBAAF1217CF39632604473['themedir'];            }          db_close();                    if($RF5AA909E0F4D8FA1B9F8B79D50267836) :                  ?>
      
      <h2>Current Theme</h2>
      
      <?php                    $RF654AD9FF3E6902129DE809955088015 = ABSPATH."/pa-content/themes/".$RF5AA909E0F4D8FA1B9F8B79D50267836."/";                             $R6F60A34405283693329C5F60404E1E46 = opendir($RF654AD9FF3E6902129DE809955088015);                   while (false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {            if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){              $RC762A21CF01F9DFBEA30DD29D5B7CBD9 = substr($R09A33463761E506248078D422B1C5226, -4);              if($RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".png" || $RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".jpg" || $RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".gif") {                $RB14C5D95245320798E3651E0653B4FF9 = painfo('url',false);                echo '<img height="150px" width="150px" src="'.                $RB14C5D95245320798E3651E0653B4FF9.                'pa-content/themes/'.$RF5AA909E0F4D8FA1B9F8B79D50267836."/".$R09A33463761E506248078D422B1C5226.'" />';                break;              }            }          }                   closedir($R6F60A34405283693329C5F60404E1E46);                    endif;        ?>
        <h2>Themes</h2>
        <table align="center" cellpadding="2" cellspacing="0">
        <?php                        $R714CA9EB87223AD2D6815F90173FDE78 = ABSPATH."/pa-content/themes/";                       $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                       while (false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                                   $R1C2D4BF6C22A76BF9AF61DB8E3073712[] = $R09A33463761E506248078D422B1C5226;                }            }                       closedir($R6F60A34405283693329C5F60404E1E46);                                   $RA1D44C0654A40984A103C270FFB9BF33 = count($R1C2D4BF6C22A76BF9AF61DB8E3073712);            $R52D5B5E885B21331CFD2304BE571DE0B = 0;                       $R5AB8048E338F99A24858D67398ABF431 = 0;                        while($R52D5B5E885B21331CFD2304BE571DE0B < $RA1D44C0654A40984A103C270FFB9BF33){                           $R714CA9EB87223AD2D6815F90173FDE78 = ABSPATH."/pa-content/themes/".$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B]."/";                           $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                             while(false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                  if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                                       $RC762A21CF01F9DFBEA30DD29D5B7CBD9 = substr($R09A33463761E506248078D422B1C5226, -4);                    if($RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".png" || $RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".jpg" || $RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".gif") {                      $RCB4D2FC53DBBBF01C703FBEB32915ED4[$R52D5B5E885B21331CFD2304BE571DE0B] = 1;                      break;                    }                    else                    {                                           $RCB4D2FC53DBBBF01C703FBEB32915ED4[$R52D5B5E885B21331CFD2304BE571DE0B] = 0;                    }                  }              }                                         closedir($R6F60A34405283693329C5F60404E1E46);                                         $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                                         while(false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                                 if($R09A33463761E506248078D422B1C5226 == "header.php") {                    $R109F95B56FEB043097641AE1993091B5[$R52D5B5E885B21331CFD2304BE571DE0B] = 1;                    break;                  }                  else                  {                                       $R109F95B56FEB043097641AE1993091B5[$R52D5B5E885B21331CFD2304BE571DE0B] = 0;                  }                }              }                                         closedir($R6F60A34405283693329C5F60404E1E46);                                         $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                                         while(false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                  if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                    if($R09A33463761E506248078D422B1C5226 == "index.php") {                      $RDC077147C7AB3328ECDF2B0982E1EF85[$R52D5B5E885B21331CFD2304BE571DE0B] = 1;                      break;                    }                    else                    {                                           $RDC077147C7AB3328ECDF2B0982E1EF85[$R52D5B5E885B21331CFD2304BE571DE0B] = 0;                    }                  }              }                                         closedir($R6F60A34405283693329C5F60404E1E46);                                         $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                                         while(false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                  if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                    if($R09A33463761E506248078D422B1C5226 == "single.php") {                      $R8F3553B5A94E19E219228A9F01663CC9[$R52D5B5E885B21331CFD2304BE571DE0B] = 1;                      break;                    }                    else                    {                                           $R8F3553B5A94E19E219228A9F01663CC9[$R52D5B5E885B21331CFD2304BE571DE0B] = 0;                    }                  }              }                                         closedir($R6F60A34405283693329C5F60404E1E46);                                         $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                                         while(false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                  if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                    if($R09A33463761E506248078D422B1C5226 == "footer.php") {                      $R1B9B9E2A109218FCE8EECBC9D1751013[$R52D5B5E885B21331CFD2304BE571DE0B] = 1;                      break;                    }                    else                    {                                           $R1B9B9E2A109218FCE8EECBC9D1751013[$R52D5B5E885B21331CFD2304BE571DE0B] = 0;                    }                  }              }                                         closedir($R6F60A34405283693329C5F60404E1E46);                                         $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                                         while(false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                  if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                    if($R09A33463761E506248078D422B1C5226 == "search.php") {                      $RDA221F146D493BE492F3819E6E90FD95[$R52D5B5E885B21331CFD2304BE571DE0B] = 1;                      break;                    }                    else                    {                                           $RDA221F146D493BE492F3819E6E90FD95[$R52D5B5E885B21331CFD2304BE571DE0B] = 0;                    }                  }              }                                         closedir($R6F60A34405283693329C5F60404E1E46);                                         if($RCB4D2FC53DBBBF01C703FBEB32915ED4[$R52D5B5E885B21331CFD2304BE571DE0B] == 0){                $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][0] = '<li>The Theme Directory "<b>'.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B].'</b>" Does Not Have A Valid Screenshot.</li>';                $R1B33F70F787A1698E61F040B7ED037E5 = 1;              }                             if($R109F95B56FEB043097641AE1993091B5[$R52D5B5E885B21331CFD2304BE571DE0B] == 0){                $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][1] = '<li>The Theme Directory "<b>'.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B].'</b>" Does Not Have A Valid <b>header.php</b> file.</li>';                $R1B33F70F787A1698E61F040B7ED037E5 = 1;              }                                         if($RDC077147C7AB3328ECDF2B0982E1EF85[$R52D5B5E885B21331CFD2304BE571DE0B] == 0){                $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][2] = '<li>The Theme Directory "<b>'.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B].'</b>" Does Not Have A Valid <b>index.php</b> file.</li>';                $R1B33F70F787A1698E61F040B7ED037E5 = 1;              }                                         if($R8F3553B5A94E19E219228A9F01663CC9[$R52D5B5E885B21331CFD2304BE571DE0B] == 0){                $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][3] = '<li>The Theme Directory "<b>'.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B].'</b>" Does Not Have A Valid <b>single.php</b> file.</li>';                $R1B33F70F787A1698E61F040B7ED037E5 = 1;              }                                         if($R1B9B9E2A109218FCE8EECBC9D1751013[$R52D5B5E885B21331CFD2304BE571DE0B] == 0){                $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][4] = '<li>The Theme Directory "<b>'.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B].'</b>" Does Not Have A Valid <b>footer.php</b> file.</li>';                $R1B33F70F787A1698E61F040B7ED037E5 = 1;              }                            if($RDA221F146D493BE492F3819E6E90FD95[$R52D5B5E885B21331CFD2304BE571DE0B] == 0){                $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][5] = '<li>The Theme Directory "<b>'.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B].'</b>" Does Not Have A Valid <b>search.php</b> file.</li>';                $R1B33F70F787A1698E61F040B7ED037E5 = 1;              }                             if($RCB4D2FC53DBBBF01C703FBEB32915ED4[$R52D5B5E885B21331CFD2304BE571DE0B] == 1 && $RDA221F146D493BE492F3819E6E90FD95[$R52D5B5E885B21331CFD2304BE571DE0B] == 1 && $R109F95B56FEB043097641AE1993091B5[$R52D5B5E885B21331CFD2304BE571DE0B] == 1 && $RDC077147C7AB3328ECDF2B0982E1EF85[$R52D5B5E885B21331CFD2304BE571DE0B] == 1 && $R8F3553B5A94E19E219228A9F01663CC9[$R52D5B5E885B21331CFD2304BE571DE0B] == 1 && $R1B9B9E2A109218FCE8EECBC9D1751013[$R52D5B5E885B21331CFD2304BE571DE0B] == 1) {                              $R5AB8048E338F99A24858D67398ABF431++;              if($R5AB8048E338F99A24858D67398ABF431 == 1) {                echo '<tr>';              }              echo '<td>';                               $R6F60A34405283693329C5F60404E1E46 = opendir($R714CA9EB87223AD2D6815F90173FDE78);                               while(false !== ($R09A33463761E506248078D422B1C5226 = readdir($R6F60A34405283693329C5F60404E1E46))) {                  if($R09A33463761E506248078D422B1C5226 != "." && $R09A33463761E506248078D422B1C5226 != ".."){                                       $RC762A21CF01F9DFBEA30DD29D5B7CBD9 = substr($R09A33463761E506248078D422B1C5226, -4);                    if($RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".png" || $RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".jpg" || $RC762A21CF01F9DFBEA30DD29D5B7CBD9 == ".gif") {                      $RB14C5D95245320798E3651E0653B4FF9 = painfo('url',false);                      echo '<a href="'.$RB14C5D95245320798E3651E0653B4FF9.'pa-admin/index.php?settheme=1&dir='.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B].'"><img height="150px" width="150px" src="'.                      $RB14C5D95245320798E3651E0653B4FF9.                      'pa-content/themes/'.$R1C2D4BF6C22A76BF9AF61DB8E3073712[$R52D5B5E885B21331CFD2304BE571DE0B]."/".$R09A33463761E506248078D422B1C5226.'" /></a>';                      break;                    }                  }                }              echo '</td>';                            if($R5AB8048E338F99A24858D67398ABF431 == 5) {                echo '</tr>';                $R5AB8048E338F99A24858D67398ABF431 = 0;              }                                               closedir($R6F60A34405283693329C5F60404E1E46);              }                $R52D5B5E885B21331CFD2304BE571DE0B++;            }                        if($R5AB8048E338F99A24858D67398ABF431 < 5) {                echo '</tr>';                $R5AB8048E338F99A24858D67398ABF431 = 0;              }                        echo '</table>';                        if($R1B33F70F787A1698E61F040B7ED037E5 == 1) :          ?>
        
        <br />
        
        <div>
          <h2>Broken Themes</h2>
          <ul>
            <?php                               $RA1D44C0654A40984A103C270FFB9BF33 = count($RB5ADDE8D7D7412251F47419FE9BF51A7);                $R52D5B5E885B21331CFD2304BE571DE0B = 0;                sort($RB5ADDE8D7D7412251F47419FE9BF51A7);                while($R52D5B5E885B21331CFD2304BE571DE0B < $RA1D44C0654A40984A103C270FFB9BF33){                                  echo $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][0];                  echo $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][1];                  echo $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][2];                  echo $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][3];                  echo $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][4];                  echo $RB5ADDE8D7D7412251F47419FE9BF51A7[$R52D5B5E885B21331CFD2304BE571DE0B][5];                  $R52D5B5E885B21331CFD2304BE571DE0B++;                }              ?>
          </ul>
        </div>
        <?php             endif;          ?>
      </div>
      <?php           endif;            if($_GET['options'] == 1 || $_GET['postoptions'] == 1) :        ?>
      <div class="dash">

  <?php 
    if($optionError){
      echo "<center>".$optionError."</center><br />";
    }
  ?>
  
  <h2>General Options</h2>
  
    <form method="post" action="http://<?php echo $_SERVER['HTTP_HOST']."/pa-admin/index.php?postoptions=1"; ?>" name="editpost">
    
    <table align="center" cellpadding="3" cellspacing="5">
      <tr>
        <td>
          <div class="adminp">
            <b>Site Name: </b> <input type="text" value="<?php if($sitename){ echo $sitename; } ?>" name="sitename" size="40" />
          </div>
        </td>
      </tr>
      
      <tr>
        <td>
          <div class="adminp">
            <b>Website URL: </b> <input type="text" value="<?php if($url){ echo $url; } ?>" name="url" size="40" />
          </div>
        </td>
      </tr>
      
      <tr>
        <td>
          <div class="adminp">
            <b>Email Address: </b> <input type="text" value="<?php if($email){ echo $email; } ?>" name="email" size="40" />
          </div>
        </td>
      </tr>
      
      <tr>
        <td>
          <div class="adminp">
            <b>Username: </b> <input maxlength="99" type="text" value="<?php if($username){ echo $username; } ?>" name="username" size="40" /><br />
            <small>(Leave This Value If You Want To Keep Your Current Username)</small>
          </div>
        </td>
      </tr>
      
      <tr>
        <td>
          <div class="adminp">
            <b>Password: </b> <input type="password" value="" name="pass" size="40" /><br />
            <small>(Leave Blank If You Want To Keep Your Current Password)</small>
          </div>
        </td>
      </tr>
      
      <tr>
        <td>
          <div class="adminp">
            <b>Confirm Password: </b> <input type="password" value="" name="passconfirm" size="40" /><br />
            <small>(Leave Blank If You Want To Keep Your Current Password)</small>
          </div>
        </td>
      </tr>
      
      <tr>
        <td>
          <div class="adminp">
            <input type="submit" name="button" value="Update Settings" />
          </div>
        </td>
      </tr>
    </table>
  </form>
  </div>
      <?php           endif;        ?>
    </div>
    
    <div id="footer"> <div style="padding-top:35px;">
      <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" width="270" height="203" id="anitextMov">
        <param name="movie" value="anitext.swf">
        <param name="quality" value="high">
        <param name="loop" value="false">
        <param name="bgcolor" value="#000000">
        <embed src="anitext.swf" quality="high" bgcolor="#000000" width="270" height="203" name="anitextMov" align="center" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed>
      </object> 
      </div>
    </div>
  </center>
  </body>
</html>

<?php     function F3A2728D0E3CD127E34A8213A7076A110() {      db_connect();        $RE91192A00FF990477EE414AD5D708F08 = "SELECT categories FROM pa_cats";        $R679E9B9234E2062F809DBD3325D37FB6 = @mysql_query($RE91192A00FF990477EE414AD5D708F08);                while($R4EEB713E57BBAAF1217CF39632604473 = @mysql_fetch_array($R679E9B9234E2062F809DBD3325D37FB6))        {          $R30E38C1F8EC85F8EE8DF620FF3267157[] = $R4EEB713E57BBAAF1217CF39632604473['categories'];        }      db_close();            $RA1D44C0654A40984A103C270FFB9BF33 = count($R30E38C1F8EC85F8EE8DF620FF3267157);      $R52D5B5E885B21331CFD2304BE571DE0B = 0;      while($R52D5B5E885B21331CFD2304BE571DE0B < $RA1D44C0654A40984A103C270FFB9BF33){              if($RCB6CF74D12D3949F4F3C570ECE4B9CB5 == $R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B]) {          echo '<input type="checkbox" value="'.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'" name="cat[]" checked /> '.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'<br />';        }        else        {          echo '<input type="checkbox" value="'.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'" name="cat[]" /> '.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'<br />';        }        $R52D5B5E885B21331CFD2304BE571DE0B++;      }    }      function FCB8065838BC38B9467571F3B5D5A53AD($RCB6CF74D12D3949F4F3C570ECE4B9CB5) {      db_connect();        $RE91192A00FF990477EE414AD5D708F08 = "SELECT categories FROM pa_cats";        $R679E9B9234E2062F809DBD3325D37FB6 = @mysql_query($RE91192A00FF990477EE414AD5D708F08);                while($R4EEB713E57BBAAF1217CF39632604473 = @mysql_fetch_array($R679E9B9234E2062F809DBD3325D37FB6))        {          $R30E38C1F8EC85F8EE8DF620FF3267157[] = $R4EEB713E57BBAAF1217CF39632604473['categories'];        }      db_close();            $RA1D44C0654A40984A103C270FFB9BF33 = count($R30E38C1F8EC85F8EE8DF620FF3267157);      $R52D5B5E885B21331CFD2304BE571DE0B = 0;      while($R52D5B5E885B21331CFD2304BE571DE0B < $RA1D44C0654A40984A103C270FFB9BF33){              if($RCB6CF74D12D3949F4F3C570ECE4B9CB5 == $R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B]) {          echo '<input type="checkbox" value="'.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'" name="cat[]" checked /> '.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'<br />';        }        else        {          echo '<input type="checkbox" value="'.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'" name="cat[]" /> '.$R30E38C1F8EC85F8EE8DF620FF3267157[$R52D5B5E885B21331CFD2304BE571DE0B].'<br />';        }        $R52D5B5E885B21331CFD2304BE571DE0B++;      }    }  ?>
