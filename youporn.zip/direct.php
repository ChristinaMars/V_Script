<?php
// ** This file is left empty because your not a reseller ** //
?>