<?php 
  // This function gets the header page you can also use
  // include_once('header.php'); if your header is not named header.php
  get_header();
?>
<div align="center" style="margin-bottom:10px;padding-top: 5px;">
  <img src="<?php painfo('url') ?>pa-content/themes/classic/images/728x90.jpg" border="0">
</div>

<fieldset style="background: #FFFFDB;margin-bottom:10px; border: 1px solid #F8EBC3; width: 98%; padding: 5px;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td align="left">
        <span class="title">
          Searching for "<?php search_results('string',false); ?>"
        </span>
      </td>
      <td align="right">
        <span class="title">
          Search Returned <?php search_results('total',false); ?> Result(s)
        </span>
      </td>
    </tr>
  </table>
</fieldset>

<table width="95%" border="0" cellspacing="10" cellpadding="0">
    <?php search_results('',true); ?>
</table>

<br />
<hr />
<br />

<table border="0" cellspacing="0" cellpadding="0">
  <?php 
    search_results('paging',false);
  ?>
  <tr>
    <td align="center">
      <form method="GET" action="<?php painfo('url'); ?>search.php" name="search">
        <input type="text" name="q" style="height: 32px; width: 350px; font-size: 20px;">
        <input type="submit" value="Search" style="height: 30px; width: 100px;">
      </form>
    </td>
  </tr>
</table>

<hr />
<?php 
  // This function gets the footer page you can also use
  // include_once('footer.php'); if your footer is not named footer.php
  get_footer();
?>
