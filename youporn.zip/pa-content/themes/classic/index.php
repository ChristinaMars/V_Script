<?php 
  get_header();
?>

<div style="margin-bottom:10px;align:center;padding-top: 5px;">
  <img src="<?php painfo('url'); ?>pa-content/themes/classic/images/728x90.jpg" border="0">
</div>

<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr valign="top">
    <td width="25%">
      <fieldset style="background: #FFFFFF; border: 1px solid #DEDEDE; padding: 5px;">
      <legend class="title"> 
        Categories 
      </legend>
      <ul>
        <?php 
          // Show all categories in list form
          list_all_cats('<li>', '</li>');
        ?>
      </ul>
      </fieldset>
      <br />
    </td>
    <td width="75%">
      <table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td colspan="2">
            <div class="title"> 
              Newest Videos
            </div>
          </td>
        </tr>
        <tr valign="top">
          <?php 
            list_thumbs('<td>', '</td>', '4');
          ?>
        </tr>
        <tr>
          <td colspan="2">
            <div class="title"> 
              Random Videos
            </div>
          </td>
        </tr>
        <tr> 
          <td>
            <?php 
              show_rand_thumb();
            ?></td> 
          <td>
            <?php 
              show_rand_thumb();
            ?></td> 
          <td>
            <?php 
              show_rand_thumb();
            ?></td> 
          <td>
            <?php 
              show_rand_thumb();
            ?>
          </td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td colspan="4">
            <hr />
          </td>
        </tr>
        <tr> 
          <td>
            <?php 
              show_rand_thumb();
            ?></td> 
          <td>
            <?php 
              show_rand_thumb();
            ?></td> 
          <td>
            <?php 
              show_rand_thumb();
            ?></td> 
          <td>
            <?php 
              show_rand_thumb();
            ?>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<hr />
<?php 
  get_footer();
?>
