<?php 
  // This function gets the header page you can also use
  // include_once('header.php'); if your header is not named header.php
  get_header();
?>

<div align="center" style="margin-bottom:10px;padding-top: 5px;">
  <img src="<?php painfo('url') ?>pa-content/themes/classic/images/728x90.jpg" border="0">
</div>

<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tr valign="top">
    <td width="50%">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td>
            <span style="margin-left:10px;">
              <?php 
                // This function embeds the video into the page based upon which Id was passed 
                // through the url
                embed();
              ?>
            </span>
          </td>
        </tr>
        <tr>
          <td><br /></td>
        </tr>
        <tr>
          <td>
              <?php 
                $content = the_content('','',false);
                if($content) {
              ?>
              
              <div class="title">
                <b>DESCRIPTION</b>
                <br />
              </div>
              
              <?php
                  the_content();
                }
              ?>
          </td>
        </tr>
        <tr>
          <td>
            <div style="margin-top:10px;" align="center">
              <img src="<?php painfo('url') ?>pa-content/themes/classic/images/468x60.jpg" border="0">
            </div>
          </td>
        </tr>
      </table>
    </td>
    <td width="50%">
    
      <div align="center">
        <img src="<?php painfo('url') ?>pa-content/themes/classic/images/300x250.jpg" border="0">
      </div>
      
      <br />
      
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td colspan="4">
            <div class="title">
              RELATED VIDEOS
            </div>
            <hr />
          </td>
        </tr>
        <tr>
          <?php
            $info = the_title('','',false);
            show_related_thumb('<td>', '</td>', '1', $info);
            show_rand_thumb('<td>', '</td>');
            show_rand_thumb('<td>', '</td>');
          ?>
        </tr>
        <tr>
          <td>
            <br />
          </td>
        </tr>
        <tr>
          <td colspan="4">
            <div class="title">
              OTHER VIDEOS
            </div>
            <hr />
          </td>
        </tr>
        <tr>
          <td>
            <br />
          </td>
        </tr>
        <tr>
          <?php
            show_rand_thumb('<td>', '</td>');
            show_rand_thumb('<td>', '</td>');
            show_rand_thumb('<td>', '</td>');
          ?>
        </tr>
    </table>
  </td>
</tr>
</table>
<hr />
<?php 
  // This function gets the footer page you can also use
  // include_once('footer.php'); if your footer is not named footer.php
  get_footer();
?>
