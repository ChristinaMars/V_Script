  
  <table width="100%" border="0" cellspacing="2" cellpadding="2">
    <tr valign="middle" align="center">
      <td width="90%">
        Copyright &copy; 2008 <b><?php painfo('url'); ?></b><br />
       This site is not affiliated with any web sites mentioned on our site except 
       where noted. By visiting this site I am affirmatively declaring that I have knowledge and 
       understand and agree that this is an "adult" site and that my date of birth is suitable to 
        visit an "adult" rated website.      </td>
    </tr>
  </table>
  
  </div>
  <small><?php painfo('powered'); ?></small>
  </center>
  <br />
  <br />
</body>
</html>
