<?php 
  authenticate();
?>

<html>
  <head>
    <title><?php         painfo('name');      ?> Sharemafi Nulled Team</title>
    <link rel="stylesheet" type="text/css" href="<?php painfo('url') ?>pa-content/themes/classic/css/style.css" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  </head>
  <body>
    <center>
      <div id="site">
        <table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr valign="middle">
            <td width="25%">
              <a href="<?php painfo('url'); ?>">
                <img src="<?php painfo('url'); ?>pa-content/themes/classic/images/logo.png" border="0">
              </a>
            </td>
            
            <td align="center" width="75%"><br />
              <form method="GET" action="<?php painfo('url'); ?>search.php" name="search">
                <input type="text" name="q" style="height: 32px; width: 350px; font-size: 20px;">
                <input type="submit" value="Search" style="height: 30px; width: 100px;">
              </form>
            </td>
          </tr>
        </table>
