<html>
  <head>
    <title>
      WARNING ADULT CONTENT AHEAD!
    </title>
    <link rel="stylesheet" type="text/css" href="<?php painfo('url') ?>pa-content/themes/classic/css/style.css" />
  </head>
  <body bgcolor="#FFFFFF" text="#000000" leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0"><br /><br /><br /><br />
    <table width="100%" border="0" cellspacing="10" cellpadding="10">
      <tr>
        <td valign="middle" align="center">
          <div class="title">
            SITE LOGO GOES HERE 
          </div></td>
      </tr>
      <tr>
        <td valign="middle" align="center">
          <p class="title">
            <font color="#ff0000">
              WARNING ADULT CONTENT AHEAD!
            </font><br />
            This site contains adult materials or materials that may be considered offensive in some 
            communities. You may not enter this site if you are easily shocked or offended or if the 
            standards of your community do not allow for the viewing of adult erotic materials!
            <br /><br />
            If You Are Under The Age Of 19 Please Leave NOW!
          </p></td>
      </tr>
      <tr>
        <td valign="middle" align="center">
          <a class="bold" href="<?php painfo('url'); 	?>index.php?verify=true">ENTER</a> &nbsp; |&nbsp;
          <a class="bold" href="http://www.google.com">LEAVE</a></td>
      </tr>
    </table>
  </body>
  </htm
