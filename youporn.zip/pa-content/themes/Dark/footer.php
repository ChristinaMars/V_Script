<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	border: 2px;
}
-->
</style>
  
  <table width="100%" border="0" cellpadding="2" cellspacing="2" bordercolor="#FF0000" class="style1">
    <tr valign="middle" align="center">
      <td width="90%">        <p>Copyright &copy; 2008 <b>
        <?php painfo('url'); ?>
        </b><br />
        This site is not affiliated with any web sites mentioned on our site except 
        where noted. By visiting this site I am affirmatively declaring that I have knowledge and 
        understand and agree that this is an "adult" site and that my date of birth is suitable to 
        visit an "adult" rated website. </p>
        <p><small>
          <?php painfo('powered'); ?>
        </small></p></td>
    </tr>
  </table>
  
</div></center>
<br />
  <br />
</body>
</html>
