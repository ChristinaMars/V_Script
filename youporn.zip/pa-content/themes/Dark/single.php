<?php
  authenticate();
?>
<title> <?php painfo('name'); ?> </title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>

<?php
  include_once('header.php');
?>

<style type="text/css"> 
<!-- 
body  {
	font: 100% Verdana, Arial, Helvetica, sans-serif;
	background: #666666;
	margin: 0; /* it's good practice to zero the margin and padding of the body element to account for differing browser defaults */
	padding: 0;
	text-align: center; /* this centers the container in IE 5* browsers. The text is then set to the left aligned default in the #container selector */
	color: #000000;
	background-color: #000000;
}
.twoColHybLtHdr #container {
	width: 80%;  /* this will create a container 80% of the browser width */
	background: #000000;
	margin: 0 auto; /* the auto margins (in conjunction with a width) center the page */
	border: 2px solid #FF0000;
	text-align: left; /* this overrides the text-align: center on the body element. */
} 
.twoColHybLtHdr #header {
	background: #000000;
	padding: 0 10px;  /* this padding matches the left alignment of the elements in the divs that appear beneath it. If an image is used in the #header instead of text, you may want to remove the padding. */
} 
.twoColHybLtHdr #header h1 {
	margin: 0; /* zeroing the margin of the last element in the #header div will avoid margin collapse - an unexplainable space between divs. If the div has a border around it, this is not necessary as that also avoids the margin collapse */
	padding: 10px 0; /* using padding instead of margin will allow you to keep the element away from the edges of the div */
}

/* Tips for sidebar1:
1. Since we are working in relative units, it's best not to use padding on the sidebar. It will be added to the overall width for standards compliant browsers creating an unknown actual width. 
2. Since em units are used for the sidebar value, be aware that its width will vary with different default text sizes.
3. Space between the side of the div and the elements within it can be created by placing a left and right margin on those elements as seen in the ".twoColHybLtHdr #sidebar1 p" rule.
*/
.twoColHybLtHdr #sidebar1 {
	float: left;
	width: 12em; /* since this element is floated, a width must be given */
	background: #000000; /* the background color will be displayed for the length of the content in the column, but no further */
	padding: 15px 0; /* top and bottom padding create visual space within this div  */
	border: 2px;
}
.twoColHybLtHdr #sidebar1 h3, .twoColHybLtHdr #sidebar1 p {
	margin-left: 10px; /* the left and right margin should be given to every element that will be placed in the side columns */
	margin-right: 10px;
}

/* Tips for mainContent:
1. The space between the mainContent and sidebar1 is created with the left margin on the mainContent div.  No matter how much content the sidebar1 div contains, the column space will remain. You can remove this left margin if you want the #mainContent div's text to fill the #sidebar1 space when the content in #sidebar1 ends.
2. Be aware it is possible to cause float drop (the dropping of the non-floated mainContent area below the sidebar) if an element wider than it can contain is placed within the mainContent div. WIth a hybrid layout (percentage-based overall width with em-based sidebar), it may not be possible to calculate the exact width available. If the user's text size is larger than average, you will have a wider sidebar div and thus, less room in the mainContent div. You should be aware of this limitation - especially if the client is adding content with Contribute.
3. In the Internet Explorer Conditional Comment below, the zoom property is used to give the mainContent "hasLayout." This may help avoid several IE-specific bugs.
*/
.twoColHybLtHdr #mainContent {
	margin: 0 20px 0 13em; /* the right margin can be given in percentages or pixels. It creates the space down the right side of the page. */
	border: 2px;
} 
.twoColHybLtHdr #footer {
	padding: 0 10px; /* this padding matches the left alignment of the elements in the divs that appear above it. */
	background:#000000;
	color: #FF0000;
	border: 3px;
} 
.twoColHybLtHdr #footer p {
	margin: 0; /* zeroing the margins of the first element in the footer will avoid the possibility of margin collapse - a space between divs */
	padding: 10px 0; /* padding on this element will create space, just as the the margin would have, without the margin collapse issue */
}

/* Miscellaneous classes for reuse */
.fltrt { /* this class can be used to float an element right in your page. The floated element must precede the element it should be next to on the page. */
	float: right;
	margin-left: 8px;
}
.fltlft { /* this class can be used to float an element left in your page */
	float: left;
	margin-right: 8px;
}
.clearfloat { /* this class should be placed on a div or break element and should be the final element before the close of a container that should fully contain a float */
	clear:both;
    height:0;
    font-size: 1px;
    line-height: 0px;
}
.style1 {color: #FF0000}
.style2 {
	font-size: 18;
	border: 2px;
	border-color: #FF0000;
}
--> 
</style><!--[if IE]>
<style type="text/css"> 
/* place css fixes for all versions of IE in this conditional comment */
.twoColHybLtHdr #sidebar1 { padding-top: 30px; }
.twoColHybLtHdr #mainContent { zoom: 1; padding-top: 15px; }
/* the above proprietary zoom property gives IE the hasLayout it may need to avoid several bugs */
</style>
<![endif]--></head>

<body class="twoColHybLtHdr">

<div id="container">
  <div id="header">
<div style="margin-bottom:10px;align:center;padding-top: 5px;">
  <div align="center"><img src="<?php painfo('url'); ?>pa-content/themes/classic/images/728x90.jpg" border="0">
  </div>
  <p>
  <hr />
  </p>
</div>
  </div>
  <div id="sidebar1">
    <h3>
      <?php
          // Show all categories in list form
          list_all_cats('<li>', '</li>');
        ?>
    </h3>
    <div class="twoColHybLtHdr" id="sidebar2">
      <h3 align="center" class="style1">New Videos</h3>
      <h3>
        <?php
              show_rand_thumb();
            ?>
      </h3>
      <p>
        <?php
              show_rand_thumb();
            ?>
      </p>
      <!-- end #sidebar1 -->
    </div>
    <!-- end #sidebar1 -->
  </div>
  <div id="mainContent">
    <h1 align="center"><span class="style1" style="margin-left:10px;">
      <?php 
                // This dispalys the title of the video and only works with this file
                the_title();
              ?>
    </span></h1>
    <h1 align="center"><span class="style2" style="margin-left:10px;">
      <?php 
                // This function embeds the video into the page based upon which Id was passed 
                // through the url
                embed();
              ?>
    </span></h1>
    <p align="center"></p>
    <h1 align="center">
      <?php
                  the_content();
              ?>
    </h1>
    <p align="center">&nbsp;</p>
    <h1 align="center"> 
      <?php
            list_thumbs('<td>', '</td>', '4');
          ?> 
    </h1>
    </p>
  <!-- end #mainContent --></div>
	<p align="center">
	  <!-- This clearing element should immediately follow the #mainContent div in order to force the #container div to contain all child floats -->
      <span style="margin-top:10px;"><img src="<?php painfo('url') ?>pa-content/themes/classic/images/468x60.jpg" alt="ad bottem" border="0"></span></p>
	<p>&nbsp;</p>
	<p><br class="clearfloat" />
  </p>
	<div id="footer">
    <hr />
    <p align="center">&nbsp;</p>
    <p align="center">
      <?php
  get_footer();
?>
      <!-- end #footer -->
    </p>
  </div>
<!-- end #container --></div>
</body>
</html>
