<html>
  <head>
    <title>
      WARNING ADULT CONTENT AHEAD!
    </title>
    <link rel="stylesheet" type="text/css" href="<?php painfo('url') ?>pa-content/themes/classic/css/style.css" />
    <style type="text/css">
<!--
.style1 {color: #0000FF}
body,td,th {
	color: #FF0000;
}
body {
	background-color: #000000;
}
.style3 {color: #333333}
.style4 {color: #FF0000}
-->
    </style>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"></head>
  <body leftmargin="0" topmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0"><br />
<br /><br /><br />
<table width="100%" border="0" cellspacing="10" cellpadding="10">
      <tr>
        <td valign="middle" align="center">
          <div class="title"></div></td>
      </tr>
      <tr>
        <td valign="middle" align="center">
          <div id="warning"> WARNING: This website contains explicit adult material. </div>
          <div id="warning2">
            <!-- Please <u>enter</u> only if you are an adult over the age of 18.<br />(or age 21 in some jurisdiction). -->
            You may only enter this Website if you are at least  18 years of age, or at least the age of majority in the jurisdiction  where you reside or from which you access this Website.  If you do not  meet these requirements, then you do not have permission to use the  Website. </div>
          <p class="title">&nbsp;</p>
        </td>
      </tr>
      <tr>
        <td height="40" align="center" valign="middle">
          <p class="style1"><a class="bold" href="<?php painfo('url'); 	?>index.php?verify=true">ENTER</a> &nbsp; |&nbsp; <a class="bold" href="http://www.google.com">LEAVE</a></p>
          <p class="style1"><small>
            <?php painfo('powered'); ?>
          </small></p></td>
  </tr>
    </table>
</body>
  </htm
