<?php 
  get_header();
?>
<html>
  <head>
    <title>
      <?php
        painfo('name');
      ?>
    </title>
   <link rel="stylesheet" type="text/css" href="<?php painfo('url') ?>pa-content/themes/classic/css/style.css" />
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<link rel="stylesheet" type="text/css" href="<?php painfo('url') ?>pa-content/themes/classic/css/style.css" />
