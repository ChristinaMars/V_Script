<?php
// ** MySQL settings ** //
$dbname = '6';    // The name of the database
$dbuser = '6';     // Your MySQL username
$dbpassword = '6'; // ...and password
$dbhost = 'localhost';    // 99% chance you won't need to change this value

// ************************ DO NOT EDIT PAST THIS POINT ***********************************

define('ABSPATH', dirname(__FILE__).'/');
define('PAINC', ABSPATH.'pa-include/');
define('TEMPLATEPATH', ABSPATH.'pa-content/themes/');

include_once(PAINC.'functions.php');
?>